Thank you for your interest in Election Manager 2016; this is the press kit for Election Manager 2016.

In this kit, you will find information about the game, along with screenshots and logos.  The actual content of the press kit can be found in the following file in this directory:

presskit.html

You can use any web browser to view this file.

Thank you!

Douglas Triggs
Ai Ling Chow
Lensflare Games LLC
http://www.lensflare.com/
